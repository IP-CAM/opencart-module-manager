CREATE TABLE IF NOT EXISTS `test_table` (
  `id` int(11) NOT NULL,
  `testval` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;